package org.junit.jupiter.api;

public class Assertions {
static boolean fail() {
	return false;
}
}
