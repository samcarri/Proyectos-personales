package tp1.p2.control.exceptions;

public class CommandInvalidPositionException extends GameException {

	public CommandInvalidPositionException(String message) {
		super(message);

	}

}
