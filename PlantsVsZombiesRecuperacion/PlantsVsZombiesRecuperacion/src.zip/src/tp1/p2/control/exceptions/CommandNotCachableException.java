package tp1.p2.control.exceptions;

public class CommandNotCachableException extends GameException {

	public CommandNotCachableException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
