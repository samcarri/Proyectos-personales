package tp1.p2.control.exceptions;

public class RecordException extends GameException {

	public RecordException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
